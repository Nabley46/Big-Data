### Here are some sources for "big data" sets you can use:

  Example data sets (you are encouraged to find others).  Most useful: 1 and 7 



  1.  http://www.data.gov e.g., http://www.dataintheclassroom.org or http://www.data.gov/opendatasites  or http://www.data.gov/united-states-datasites (data for all states; CT data is under #7)

  2. https://explore.data.gov/Population/Tax-Year-2007-County-Income-Data/wvps-imhx 

  3. Social Security baby names: http://www.ssa.gov/oact/babynames, e.g., http://www.ssa.gov/oact/babynames/decades/century.html 

  4. Stanford data sets: http://snap.stanford.edu/data, e.g., data set of web links at http://snap.stanford.edu/data/web-Stanford.html 

  5.  Open Data: https://opendata.socrata.com, e.g., NYC data, SAT data,

  6.  World Bank:  http://data.worldbank.org

  7.  Transparency in Government: http://transparency.ct.gov/html/downloads.asp under download data

  8. NYU large economic data sets.http://pages.stern.nyu.edu/~adamodar/New_Home_Page/data.html

  9. Department of Ed Data sets can be found for 500 rows http://nces.ed.gov/ccd/data_tables.asp

  10. Global Terrorism site that gives an export of 1000 but you can request the full database. Like for region it was over 5000. OR copy and past the 20 webpages into excel and export as csv.  http://www.start.umd.edu/gtd/

  11. unclaimed bank accounts  https://opendata.socrata.com/Government/Unclaimed-bank-accounts/n2rk-fwkj

  12. Airplane Crashes and Fatalities Since 1908  https://opendata.socrata.com/Government/Airplane-Crashes-and-Fatalities-Since-1908/q2te-8cvq

  13. Causeweb.org has some data sets linked: http://www.causeweb.org/cwis/SPT--BrowseResources.php?ParentId=5

  14. NYC Data Sets https://data.cityofnewyork.us/
